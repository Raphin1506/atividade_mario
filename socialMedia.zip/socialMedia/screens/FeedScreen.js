import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Button } from 'react-native';

const FeedScreen = ({ navigation }) => {
  const [feedData, setFeedData] = useState([
    { id: '1', user: 'Lucas Silva', content: 'Minha primeira postagem!' },
    { id: '2', user: 'Matheus', content: 'Isso sim é ser raiz!' },
    { id: '3', user: 'Jose Augusto', content: 'Bora trabalhar Haha' },
  ]);

  const handleAddPost = (newPost) => {
    setFeedData((prevData) => [...prevData, newPost]);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={feedData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.post}>
            <Text style={styles.user}>{item.user}</Text>
            <Text>{item.content}</Text>
            <TouchableOpacity 
              onPress={() => navigation.navigate('Profile', { user: item.user })} // Navegar para o perfil
            >
              <Text style={styles.profileLink}>Ver Perfil</Text>
            </TouchableOpacity>
          </View>
        )}
      />
      <Button 
        title="Criar Postagem" 
        onPress={() => navigation.navigate('CreatePost', { addPost: handleAddPost })} 
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  post: {
    marginBottom: 20,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  user: {
    fontWeight: 'bold',
  },
  profileLink: {
    color: '#007bff',
    marginTop: 5,
  },
});

export default FeedScreen;
