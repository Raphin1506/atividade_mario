import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { CheckBox } from 'react-native-elements';
import { Picker } from '@react-native-picker/picker';

const SettingsScreen = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [language, setLanguage] = useState('pt');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Configurações</Text>

      <Text style={styles.label}>Tema</Text>
      <CheckBox
        title="Modo Escuro"
        checked={darkMode}
        onPress={() => setDarkMode(!darkMode)}
      />

      <Text style={styles.label}>Idioma</Text>
      <Picker
        selectedValue={language}
        onValueChange={(itemValue) => setLanguage(itemValue)}
        style={styles.picker}
      >
        <Picker.Item label="Português" value="pt" />
        <Picker.Item label="Inglês" value="en" />
        <Picker.Item label="Espanhol" value="es" />
      </Picker>

      <TouchableOpacity style={styles.saveButton}>
        <Text style={styles.saveButtonText}>Salvar</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  label: { fontSize: 18, marginBottom: 10 },
  picker: { height: 50, width: '100%', marginBottom: 20 },
  saveButton: {
    backgroundColor: '#28a745',
    padding: 15,
    alignItems: 'center',
    borderRadius: 5,
    marginTop: 20,
  },
  saveButtonText: { color: '#fff', fontWeight: 'bold' },
});

export default SettingsScreen;
