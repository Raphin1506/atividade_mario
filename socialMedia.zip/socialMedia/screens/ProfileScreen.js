import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ProfileScreen = ({ route }) => {
  const { user } = route.params; // Receber o nome do usuário

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Perfil de {user}</Text>
      <Text>Aqui você pode adicionar mais informações sobre o usuário.</Text>
      {/* Adicione mais informações ou ações para editar o perfil, etc. */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;
