import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';

const CreatePostScreen = ({ route, navigation }) => {
  const { addPost } = route.params; // Receber a função de adicionar post
  const [content, setContent] = useState('');

  const handleCreatePost = () => {
    if (content.trim() === '') {
      Alert.alert('Erro', 'O conteúdo da postagem não pode estar vazio.');
      return;
    }

    const newPost = {
      id: Math.random().toString(),
      user: 'Usuário Exemplo', // Aqui você pode pegar o nome do usuário logado
      content,
    };

    // Adicionar nova postagem ao feed
    addPost(newPost);

    // Navegar de volta para a tela de Feed
    navigation.navigate('Feed');
    
    // Limpar campos após criar a postagem
    setContent('');
  };

  return (
    <View style={styles.container}>
      <TextInput 
        style={styles.input} 
        placeholder="Conteúdo da Postagem" 
        value={content}
        onChangeText={setContent}
      />
      <Button title="Criar Postagem" onPress={handleCreatePost} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    marginBottom: 20,
  },
});

export default CreatePostScreen;
